import java.util.ArrayList;
import java.util.Scanner;

public class TelephoneDirectory {


    private static class Contact {
        String name;
        String phoneNumber;

        Contact(String name, String phoneNumber) {
            this.name = name;
            this.phoneNumber = phoneNumber;
        }
    }


    private ArrayList<Contact> contacts;

    public TelephoneDirectory() {
        contacts = new ArrayList<>();
    }

    public boolean isNameExists(String name) {
        for (Contact contact : contacts) {
            if (contact.name.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean addContact(String name, String phoneNumber) {
        if (isNameExists(name)) {
            return false;
        }
        contacts.add(new Contact(name, phoneNumber));
        return true;
    }

    public boolean updateContact(String name, String newPhoneNumber) {
        for (Contact contact : contacts) {
            if (contact.name.equalsIgnoreCase(name)) {
                contact.phoneNumber = newPhoneNumber;
                return true;
            }
        }
        return false;
    }

    public String getPhoneNumberByName(String name) {
        for (Contact contact : contacts) {
            if (contact.name.equalsIgnoreCase(name)) {
                return contact.phoneNumber;
            }
        }
        return null;
    }

    public boolean deleteContact(String name) {
        for (Contact contact : contacts) {
            if (contact.name.equalsIgnoreCase(name)) {
                contacts.remove(contact);
                return true;
            }
        }
        return false;
    }

    public void displayAllContacts() {
        if (contacts.isEmpty()) {
            System.out.println("Directory is empty.");
        } else {
            System.out.println("\nTelephone Directory Listings:");
            for (Contact contact : contacts) {
                System.out.println(contact.name + ": " + contact.phoneNumber);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TelephoneDirectory directory = new TelephoneDirectory();

        boolean running = true;
        while (running) {
            System.out.println("\n--- Telephone Directory Menu ---");
            System.out.println("1. Add new contact");
            System.out.println("2. Update existing contact");
            System.out.println("3. Look up phone number");
            System.out.println("4. Delete contact");
            System.out.println("5. Display all contacts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            String input = scanner.nextLine().trim();

            switch (input) {
                case "1":
                    System.out.print("Enter name: ");
                    String newName = scanner.nextLine().trim();
                    if (directory.isNameExists(newName)) {
                        System.out.println("The name is used by another customer. Please enter a different name.");
                    } else {
                        System.out.print("Enter phone number: ");
                        String newNumber = scanner.nextLine().trim();
                        directory.addContact(newName, newNumber);
                        System.out.println("Contact added successfully.");
                    }
                    break;

                case "2":
                    System.out.print("Enter name to update: ");
                    String nameToUpdate = scanner.nextLine().trim();
                    System.out.print("Enter new phone number: ");
                    String updatedNumber = scanner.nextLine().trim();

                    if (directory.updateContact(nameToUpdate, updatedNumber)) {
                        System.out.println("Contact updated successfully.");
                    } else {
                        System.out.println("Name not found in directory.");
                    }
                    break;

                case "3":
                    System.out.print("Enter name to look up: ");
                    String nameToLookUp = scanner.nextLine().trim();
                    String foundNumber = directory.getPhoneNumberByName(nameToLookUp);

                    if (foundNumber != null) {
                        System.out.println(nameToLookUp + ": " + foundNumber);
                    } else {
                        System.out.println("Name not found in directory.");
                    }
                    break;

                case "4":
                    System.out.print("Enter name to delete: ");
                    String nameToDelete = scanner.nextLine().trim();

                    if (directory.deleteContact(nameToDelete)) {
                        System.out.println("Contact deleted successfully.");
                    } else {
                        System.out.println("Name not found in directory.");
                    }
                    break;

                case "5":
                    directory.displayAllContacts();
                    break;

                case "6":
                    System.out.println("Exiting the Telephone Directory. Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 6.");
            }
        }

        scanner.close();
    }
}
